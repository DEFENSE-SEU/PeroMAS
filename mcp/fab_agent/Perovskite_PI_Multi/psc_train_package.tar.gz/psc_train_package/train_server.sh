#!/bin/bash
# ============================================================
# 钙钛矿性质预测模型训练脚本
# ============================================================
# 使用方法:
#   bash train_server.sh           # 训练所有模型
#   bash train_server.sh comp RF   # 只训练 comp_only + RF
#   bash train_server.sh cif NN    # 只训练 cif_only + NN
# ============================================================

set -e  # 遇到错误立即退出

echo "============================================================"
echo "钙钛矿性质预测模型训练"
echo "开始时间: $(date)"
echo "============================================================"

# 创建必要目录
mkdir -p logs
mkdir -p data/csr
mkdir -p data/model
mkdir -p data/model/hyperopt

# 参数解析
MODE=${1:-"all"}     # comp, cif, all
MODEL=${2:-"RF"}     # RF, GBDT, NN

echo "训练模式: $MODE"
echo "模型类型: $MODEL"

# 检查数据文件
if [ ! -f "data/raw/full_dataset.csv" ]; then
    echo "错误: 找不到数据文件 data/raw/full_dataset.csv"
    exit 1
fi

echo "数据文件检查通过"
echo ""

# 训练函数
train_model() {
    local use_x=$1
    local model_name=$2
    
    echo "============================================================"
    echo "训练: ${use_x} + ${model_name}"
    echo "============================================================"
    
    python train_models.py --mode ${use_x} --model ${model_name}
    
    echo "完成: ${use_x} + ${model_name}"
    echo ""
}

# 根据参数执行训练
case $MODE in
    "comp")
        train_model "comp_only" "$MODEL"
        ;;
    "cif")
        train_model "cif_only" "$MODEL"
        ;;
    "all")
        echo "训练所有模型组合..."
        train_model "comp_only" "RF"
        train_model "cif_only" "RF"
        train_model "comp_only" "NN"
        train_model "cif_only" "NN"
        ;;
    *)
        echo "未知模式: $MODE"
        echo "可用模式: comp, cif, all"
        exit 1
        ;;
esac

echo "============================================================"
echo "所有训练完成!"
echo "结束时间: $(date)"
echo "============================================================"

# 列出生成的模型文件
echo ""
echo "生成的模型文件:"
ls -lh data/model/*.pkl 2>/dev/null || echo "没有找到模型文件"

echo ""
echo "特征缓存文件:"
ls -lh data/csr/*.npz 2>/dev/null || echo "没有找到特征缓存"
